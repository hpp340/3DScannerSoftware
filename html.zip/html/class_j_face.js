var class_j_face =
[
    [ "JFace", "class_j_face.html#aa6dca0fe48258def617da3499f4169a8", null ],
    [ "JFace", "class_j_face.html#ab13e7736d100b7550846e601179d163b", null ],
    [ "JFace", "class_j_face.html#a63233cea6d98de85b8bee78575d7eccb", null ],
    [ "JFace", "class_j_face.html#aa041f73bd0136c3ef7c17b39264e7eab", null ],
    [ "~JFace", "class_j_face.html#a822b0411f1a280ac8ae6a33e7a90c546", null ],
    [ "getFaceNormal", "class_j_face.html#a6f473d4424af8040df74786286096723", null ],
    [ "isNormalSet", "class_j_face.html#a0de65c39bc803e2a0ef98c9bc748fd39", null ],
    [ "isTextureSet", "class_j_face.html#afb59a90a8aa4636234732dfbce773c52", null ],
    [ "setFaceId", "class_j_face.html#ac92f58e0feafffdffe435dc54b40d38d", null ],
    [ "setFaceNormal", "class_j_face.html#af1d5c05f67f16334b985cf55210b7978", null ],
    [ "faceId", "class_j_face.html#a6a9e159e18a079e66a29dc542120da61", null ],
    [ "faceNormal", "class_j_face.html#a9f8a2361d10f27486d319159bbe6b940", null ],
    [ "normalSet", "class_j_face.html#a8094fcfcd50d20de95bb931f902ce0d5", null ],
    [ "texture1Id", "class_j_face.html#a1f4d1a661862f834fb3141aefd7aa6e7", null ],
    [ "texture2Id", "class_j_face.html#a1bc1065ee5da8c2e38b87abda134a48d", null ],
    [ "texture3Id", "class_j_face.html#a58c8bd5511a13b537b3fba6552bc131e", null ],
    [ "textureSet", "class_j_face.html#a1c34291cb15bf453daee26392040ac2d", null ],
    [ "vert1Id", "class_j_face.html#a08c674e1e03d04b3bf38071b3fbe8d8e", null ],
    [ "vert2Id", "class_j_face.html#a8a581a6ed16895c491a6df00cf6be01e", null ],
    [ "vert3Id", "class_j_face.html#a7fbebc61d3ade86f7626cfd40529a5cc", null ]
];