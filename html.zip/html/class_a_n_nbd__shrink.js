var class_a_n_nbd__shrink =
[
    [ "ANNbd_shrink", "class_a_n_nbd__shrink.html#a5a237183dfd0646b2c90aa2bb282ba71", null ],
    [ "~ANNbd_shrink", "class_a_n_nbd__shrink.html#a1dd5b9b46f66329ed409cd4b508a27cc", null ],
    [ "ann_FR_search", "class_a_n_nbd__shrink.html#a87afc7f96e0203b7d5149ca3aec65d57", null ],
    [ "ann_pri_search", "class_a_n_nbd__shrink.html#adb5b5c04e63c394e650ae3fc7e195989", null ],
    [ "ann_search", "class_a_n_nbd__shrink.html#a56bedc3fbf48f37c82aa6ea5228cc97e", null ],
    [ "dump", "class_a_n_nbd__shrink.html#a51d412cbad1b7823437adf97050d8880", null ],
    [ "getStats", "class_a_n_nbd__shrink.html#a37a635b661ebb1b18ec6ab68df92a2b4", null ],
    [ "print", "class_a_n_nbd__shrink.html#a41b772faa781609ff39da6a269c16662", null ],
    [ "bnds", "class_a_n_nbd__shrink.html#af37a99b5d5b1c460e31ea5b9ca994e3f", null ],
    [ "child", "class_a_n_nbd__shrink.html#a6b50ec4569620af69946e62106eeb5a7", null ],
    [ "n_bnds", "class_a_n_nbd__shrink.html#aa39fd79dab4163b3ff8a0af60fec9742", null ]
];