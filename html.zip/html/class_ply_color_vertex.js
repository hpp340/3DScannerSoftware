var class_ply_color_vertex =
[
    [ "PlyColorVertex", "class_ply_color_vertex.html#a26fb83ea478cde2cbe9347fb4435d870", null ],
    [ "PlyColorVertex", "class_ply_color_vertex.html#aca327b5485f6244a46e5c688cc0316e6", null ],
    [ "operator const Point3D< Real > &", "class_ply_color_vertex.html#a6444fb2033ba0896c7845a30de78067d", null ],
    [ "operator Point3D< Real > &", "class_ply_color_vertex.html#a797d5363a0119846aba647d3b3f8157e", null ],
    [ "Properties", "class_ply_color_vertex.html#a886b5d160ffcdb5cf0984a296b5abc8c", null ],
    [ "Properties", "class_ply_color_vertex.html#abebd967e897d7566c982abfbc0c1ac79", null ],
    [ "color", "class_ply_color_vertex.html#a2fad81e6944438a7774c84db8024eee3", null ],
    [ "point", "class_ply_color_vertex.html#a8810f58fab7d03b826351379f53e31c9", null ]
];