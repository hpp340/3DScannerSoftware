var class_starting_polynomial =
[
    [ "operator*", "class_starting_polynomial.html#acaaec5bc21c07f61268e09083db83117", null ],
    [ "operator<", "class_starting_polynomial.html#ab95721a88ba2436e19e1e566ead4c5bf", null ],
    [ "scale", "class_starting_polynomial.html#a307c1e934cc2bf890a6cd23114f8f684", null ],
    [ "shift", "class_starting_polynomial.html#a921acf007447e5bb83984645ac9ead12", null ],
    [ "p", "class_starting_polynomial.html#a6fcbd796da4eea560cce7a835294afd4", null ],
    [ "start", "class_starting_polynomial.html#a5c0caafb5a66483803ba270615f5dffb", null ]
];