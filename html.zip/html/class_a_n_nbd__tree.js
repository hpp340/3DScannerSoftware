var class_a_n_nbd__tree =
[
    [ "ANNbd_tree", "class_a_n_nbd__tree.html#a6f947fa8ce26e0ccae9dd1b7651a5e1f", null ],
    [ "ANNbd_tree", "class_a_n_nbd__tree.html#affc85f82bf003672cb9b05176617fee8", null ],
    [ "ANNbd_tree", "class_a_n_nbd__tree.html#a8c68b938a359d6c307284d7bcf7fe273", null ]
];