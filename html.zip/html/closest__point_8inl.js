var closest__point_8inl =
[
    [ "glm_gtx_closest_point", "closest__point_8inl.html#af884ff4983e76fd2ef24511db8e29251", null ],
    [ "closestPointOnLine", "closest__point_8inl.html#ga03a6d7e93590f5d45050f6dc7aa8bf8f", null ]
];