var class_edge =
[
    [ "Length", "class_edge.html#a9402ea45953203bf203fe3a6ddf9dd7f", null ],
    [ "p", "class_edge.html#af803e62eb12a1757acb08d4b0f0bcfd1", null ]
];