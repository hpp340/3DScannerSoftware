var class_a_n_nbrute_force =
[
    [ "ANNbruteForce", "class_a_n_nbrute_force.html#adf86620260f8a08784a745fde28e67a1", null ],
    [ "~ANNbruteForce", "class_a_n_nbrute_force.html#aa04ee5206b8376ec166d94a9ebc22bfa", null ],
    [ "annkFRSearch", "class_a_n_nbrute_force.html#a2b72f0687a5fc325471213b1b42f932f", null ],
    [ "annkSearch", "class_a_n_nbrute_force.html#ac18a8d4dd4550a8336228d0d219cbc18", null ],
    [ "nPoints", "class_a_n_nbrute_force.html#acbf6eef7ce9c6999435c62f678afaba4", null ],
    [ "theDim", "class_a_n_nbrute_force.html#ad7894b12b925b0c3bbeb57d5ba260285", null ],
    [ "thePoints", "class_a_n_nbrute_force.html#a97a436f7288964a2f7cb84ce3d056350", null ],
    [ "dim", "class_a_n_nbrute_force.html#aa17b6400fe3b3ee95a5a7a670f17ae83", null ],
    [ "n_pts", "class_a_n_nbrute_force.html#a4bf36c30c1a49faf23c878cd253ae868", null ],
    [ "pts", "class_a_n_nbrute_force.html#a162583a33b71ec98ebc29a51fa594fba", null ]
];