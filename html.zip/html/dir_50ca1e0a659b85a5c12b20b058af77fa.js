var dir_50ca1e0a659b85a5c12b20b058af77fa =
[
    [ "ANN.cpp", "_a_n_n_8cpp.html", "_a_n_n_8cpp" ],
    [ "ANN.h", "_a_n_n_8h.html", "_a_n_n_8h" ],
    [ "ANNperf.h", "_a_n_nperf_8h.html", "_a_n_nperf_8h" ],
    [ "ANNx.h", "_a_n_nx_8h.html", "_a_n_nx_8h" ],
    [ "bd_fix_rad_search.cpp", "bd__fix__rad__search_8cpp.html", null ],
    [ "bd_pr_search.cpp", "bd__pr__search_8cpp.html", null ],
    [ "bd_search.cpp", "bd__search_8cpp.html", null ],
    [ "bd_tree.cpp", "bd__tree_8cpp.html", "bd__tree_8cpp" ],
    [ "bd_tree.h", "bd__tree_8h.html", [
      [ "ANNbd_shrink", "class_a_n_nbd__shrink.html", "class_a_n_nbd__shrink" ]
    ] ],
    [ "brute.cpp", "brute_8cpp.html", null ],
    [ "kd_dump.cpp", "kd__dump_8cpp.html", "kd__dump_8cpp" ],
    [ "kd_fix_rad_search.cpp", "kd__fix__rad__search_8cpp.html", "kd__fix__rad__search_8cpp" ],
    [ "kd_fix_rad_search.h", "kd__fix__rad__search_8h.html", "kd__fix__rad__search_8h" ],
    [ "kd_pr_search.cpp", "kd__pr__search_8cpp.html", "kd__pr__search_8cpp" ],
    [ "kd_pr_search.h", "kd__pr__search_8h.html", "kd__pr__search_8h" ],
    [ "kd_search.cpp", "kd__search_8cpp.html", "kd__search_8cpp" ],
    [ "kd_search.h", "kd__search_8h.html", "kd__search_8h" ],
    [ "kd_split.cpp", "kd__split_8cpp.html", "kd__split_8cpp" ],
    [ "kd_split.h", "kd__split_8h.html", "kd__split_8h" ],
    [ "kd_tree.cpp", "kd__tree_8cpp.html", "kd__tree_8cpp" ],
    [ "kd_tree.h", "kd__tree_8h.html", "kd__tree_8h" ],
    [ "kd_util.cpp", "kd__util_8cpp.html", "kd__util_8cpp" ],
    [ "kd_util.h", "kd__util_8h.html", "kd__util_8h" ],
    [ "perf.cpp", "perf_8cpp.html", "perf_8cpp" ],
    [ "pr_queue.h", "pr__queue_8h.html", "pr__queue_8h" ],
    [ "pr_queue_k.h", "pr__queue__k_8h.html", "pr__queue__k_8h" ]
];