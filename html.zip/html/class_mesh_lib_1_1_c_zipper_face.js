var class_mesh_lib_1_1_c_zipper_face =
[
    [ "CZipperFace", "class_mesh_lib_1_1_c_zipper_face.html#a0c5800ccc6e27d6463505d61751ff5f0", null ],
    [ "~CZipperFace", "class_mesh_lib_1_1_c_zipper_face.html#aa0883cfe6a14015c73e9b1159a710000", null ],
    [ "area", "class_mesh_lib_1_1_c_zipper_face.html#a651f0d0a8d2ff7bec54b104f28825b0e", null ],
    [ "normal", "class_mesh_lib_1_1_c_zipper_face.html#ad4301d2fc4297dea30742370efc0faa0", null ],
    [ "m_area", "class_mesh_lib_1_1_c_zipper_face.html#a125212b730e9ac268c27b8316695a807", null ],
    [ "m_normal", "class_mesh_lib_1_1_c_zipper_face.html#aa163f979c62302e2f96a01b0d3fc9e0b", null ]
];