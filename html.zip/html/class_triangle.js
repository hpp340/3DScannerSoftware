var class_triangle =
[
    [ "Area", "class_triangle.html#ab1b5c31cde7f8b2c1c26b4d8d6b4d24d", null ],
    [ "AspectRatio", "class_triangle.html#ab3538504bf75006defc04f382a2942d8", null ],
    [ "p", "class_triangle.html#a9e323cf72eaa6936188087afde830743", null ]
];