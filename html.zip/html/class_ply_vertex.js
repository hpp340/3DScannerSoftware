var class_ply_vertex =
[
    [ "PlyVertex", "class_ply_vertex.html#ae618c123462b4f6f3f3af16c9d24ecef", null ],
    [ "PlyVertex", "class_ply_vertex.html#aa157d106d5f7992732ca47b8ea8a5f65", null ],
    [ "operator*", "class_ply_vertex.html#a006bba7dc980e698ed6c50c32312ff1a", null ],
    [ "operator*=", "class_ply_vertex.html#af850e518faa3756f0e821242256247ac", null ],
    [ "operator+", "class_ply_vertex.html#a809aafad6d9e6c4c4e01b85488b2bb9e", null ],
    [ "operator+=", "class_ply_vertex.html#a3aa23d85e619eeeeccd19e410b262a48", null ],
    [ "operator-", "class_ply_vertex.html#a2f4321dbbca96a1b2552e08f63481ee2", null ],
    [ "operator-=", "class_ply_vertex.html#afc3f7ec454d102e96045f41b90666f6a", null ],
    [ "operator/", "class_ply_vertex.html#acbdce100c17269edf230c34f2a88b3c0", null ],
    [ "operator/=", "class_ply_vertex.html#a03696f0412a6f54828b6934e746a42ce", null ],
    [ "Properties", "class_ply_vertex.html#a6e7314879773c997e9d5725aec3273b5", null ],
    [ "Properties", "class_ply_vertex.html#a7656b27c98280afd24b5232ea64c5cb5", null ],
    [ "point", "class_ply_vertex.html#adc07ad8263305a0f57480fef14975cd8", null ]
];