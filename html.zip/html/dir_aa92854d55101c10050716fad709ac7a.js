var dir_aa92854d55101c10050716fad709ac7a =
[
    [ "Allocator.h", "_allocator_8h.html", [
      [ "AllocatorState", "class_allocator_state.html", "class_allocator_state" ],
      [ "Allocator", "class_allocator.html", "class_allocator" ]
    ] ],
    [ "Array.h", "_array_8h.html", "_array_8h" ],
    [ "Array.inl", "_array_8inl.html", "_array_8inl" ],
    [ "BinaryNode.h", "_binary_node_8h.html", "_binary_node_8h" ],
    [ "BSplineData.h", "_b_spline_data_8h.html", "_b_spline_data_8h" ],
    [ "BSplineData.inl", "_b_spline_data_8inl.html", "_b_spline_data_8inl" ],
    [ "CmdLineParser.cpp", "_cmd_line_parser_8cpp.html", "_cmd_line_parser_8cpp" ],
    [ "CmdLineParser.h", "_cmd_line_parser_8h.html", "_cmd_line_parser_8h" ],
    [ "CmdLineParser.inl", "_cmd_line_parser_8inl.html", null ],
    [ "Factor.cpp", "_factor_8cpp.html", "_factor_8cpp" ],
    [ "Factor.h", "_factor_8h.html", "_factor_8h" ],
    [ "FunctionData.h", "_function_data_8h.html", "_function_data_8h" ],
    [ "FunctionData.inl", "_function_data_8inl.html", null ],
    [ "Geometry.cpp", "_geometry_8cpp.html", null ],
    [ "Geometry.h", "_geometry_8h.html", "_geometry_8h" ],
    [ "Geometry.inl", "_geometry_8inl.html", "_geometry_8inl" ],
    [ "Hash.h", "_hash_8h.html", [
      [ "hash< long long >", "struct____gnu__cxx_1_1hash_3_01long_01long_01_4.html", "struct____gnu__cxx_1_1hash_3_01long_01long_01_4" ],
      [ "hash< const long long >", "struct____gnu__cxx_1_1hash_3_01const_01long_01long_01_4.html", "struct____gnu__cxx_1_1hash_3_01const_01long_01long_01_4" ],
      [ "hash< unsigned long long >", "struct____gnu__cxx_1_1hash_3_01unsigned_01long_01long_01_4.html", "struct____gnu__cxx_1_1hash_3_01unsigned_01long_01long_01_4" ],
      [ "hash< const unsigned long long >", "struct____gnu__cxx_1_1hash_3_01const_01unsigned_01long_01long_01_4.html", "struct____gnu__cxx_1_1hash_3_01const_01unsigned_01long_01long_01_4" ]
    ] ],
    [ "MarchingCubes.cpp", "_marching_cubes_8cpp.html", null ],
    [ "MarchingCubes.h", "_marching_cubes_8h.html", [
      [ "Square", "class_square.html", null ],
      [ "Cube", "class_cube.html", null ],
      [ "MarchingSquares", "class_marching_squares.html", null ],
      [ "MarchingCubes", "class_marching_cubes.html", null ]
    ] ],
    [ "MAT.h", "_m_a_t_8h.html", [
      [ "MinimalAreaTriangulation", "class_minimal_area_triangulation.html", "class_minimal_area_triangulation" ]
    ] ],
    [ "MAT.inl", "_m_a_t_8inl.html", null ],
    [ "MemoryUsage.h", "_memory_usage_8h.html", [
      [ "MemoryInfo", "class_memory_info.html", null ]
    ] ],
    [ "MultiGridOctreeData.h", "_multi_grid_octree_data_8h.html", "_multi_grid_octree_data_8h" ],
    [ "MultiGridOctreeData.inl", "_multi_grid_octree_data_8inl.html", "_multi_grid_octree_data_8inl" ],
    [ "Octree.h", "_octree_8h.html", "_octree_8h" ],
    [ "Octree.inl", "_octree_8inl.html", "_octree_8inl" ],
    [ "Ply.h", "_ply_8h.html", "_ply_8h" ],
    [ "PlyFile.cpp", "_ply_file_8cpp.html", "_ply_file_8cpp" ],
    [ "PlyFile.h", "_ply_file_8h.html", "_ply_file_8h" ],
    [ "PointStream.h", "_point_stream_8h.html", [
      [ "PointStream", "class_point_stream.html", "class_point_stream" ],
      [ "ASCIIPointStream", "class_a_s_c_i_i_point_stream.html", "class_a_s_c_i_i_point_stream" ],
      [ "BinaryPointStream", "class_binary_point_stream.html", "class_binary_point_stream" ],
      [ "PLYPointStream", "class_p_l_y_point_stream.html", "class_p_l_y_point_stream" ]
    ] ],
    [ "PointStream.inl", "_point_stream_8inl.html", null ],
    [ "Polynomial.h", "_polynomial_8h.html", [
      [ "Polynomial", "class_polynomial.html", "class_polynomial" ]
    ] ],
    [ "Polynomial.inl", "_polynomial_8inl.html", "_polynomial_8inl" ],
    [ "PPolynomial.h", "_p_polynomial_8h.html", [
      [ "StartingPolynomial", "class_starting_polynomial.html", "class_starting_polynomial" ],
      [ "PPolynomial", "class_p_polynomial.html", "class_p_polynomial" ]
    ] ],
    [ "PPolynomial.inl", "_p_polynomial_8inl.html", null ],
    [ "SparseMatrix.h", "_sparse_matrix_8h.html", "_sparse_matrix_8h" ],
    [ "SparseMatrix.inl", "_sparse_matrix_8inl.html", null ],
    [ "Time.cpp", "_time_8cpp.html", "_time_8cpp" ],
    [ "Time.h", "_time_8h.html", "_time_8h" ],
    [ "Vector.h", "_vector_8h.html", "_vector_8h" ],
    [ "Vector.inl", "_vector_8inl.html", "_vector_8inl" ]
];