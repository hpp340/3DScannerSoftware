var class_root_info =
[
    [ "TreeOctNode", "class_root_info.html#a6364a2ea4dffa816bc39d3fe071abedd", null ],
    [ "edgeIndex", "class_root_info.html#ae26d06ebd33a8c9748c9f062a1652f1c", null ],
    [ "key", "class_root_info.html#a24e8c50ddcad5c0078f8f5674b9544be", null ],
    [ "node", "class_root_info.html#a1d0f1aa61830ea64e6eb3fdd76bd6a4e", null ]
];