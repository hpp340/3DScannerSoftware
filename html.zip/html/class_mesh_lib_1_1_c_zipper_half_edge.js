var class_mesh_lib_1_1_c_zipper_half_edge =
[
    [ "CZipperHalfEdge", "class_mesh_lib_1_1_c_zipper_half_edge.html#a1f5fe1ca8b9908661582fbf9b4ebd7e8", null ],
    [ "~CZipperHalfEdge", "class_mesh_lib_1_1_c_zipper_half_edge.html#acc58941612e05dd612c2c7437e8d7942", null ],
    [ "angle", "class_mesh_lib_1_1_c_zipper_half_edge.html#aace9d6b81ad6f537c3404b7abbf336d6", null ],
    [ "m_angle", "class_mesh_lib_1_1_c_zipper_half_edge.html#a420ae061b461162b12a8703bd3408947", null ]
];