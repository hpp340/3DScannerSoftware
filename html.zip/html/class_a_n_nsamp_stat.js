var class_a_n_nsamp_stat =
[
    [ "ANNsampStat", "class_a_n_nsamp_stat.html#a9f19db1ce9dfe4c28e24aa5165948254", null ],
    [ "max", "class_a_n_nsamp_stat.html#ad42511f02ba75bc3c1021724ba11d2ee", null ],
    [ "mean", "class_a_n_nsamp_stat.html#a160bb296a7529384af88731b45b2cfcf", null ],
    [ "min", "class_a_n_nsamp_stat.html#a6b9978f9a76c46b3b0794e5887eb6cb1", null ],
    [ "operator+=", "class_a_n_nsamp_stat.html#a2213787291e70f24c873e2483c3ea0da", null ],
    [ "reset", "class_a_n_nsamp_stat.html#a3bd02812439e763a28a538554c5cbc41", null ],
    [ "samples", "class_a_n_nsamp_stat.html#a4ba7393a26ec5760b4e5efbc2fd6cf50", null ],
    [ "stdDev", "class_a_n_nsamp_stat.html#aa5f55b125a8f8b510ede9b92d394ff71", null ],
    [ "maxVal", "class_a_n_nsamp_stat.html#aa7a6f8d44ecd769972ca3f2ba99cc3ea", null ],
    [ "minVal", "class_a_n_nsamp_stat.html#ab2872786f4a4d6a38ebfb9586abe9147", null ],
    [ "n", "class_a_n_nsamp_stat.html#a214c592fbbdf98714583c74501b8a637", null ],
    [ "sum", "class_a_n_nsamp_stat.html#a41c4fd9c20bb36f3ce57fd00e517d1e7", null ],
    [ "sum2", "class_a_n_nsamp_stat.html#a7270d792a062a06dea51370f51b074f5", null ]
];