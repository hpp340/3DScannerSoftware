var color__space___y_co_cg_8inl =
[
    [ "rgb2YCoCg", "color__space___y_co_cg_8inl.html#ga2a235b86e67866fd9fef640bcc47c93d", null ],
    [ "rgb2YCoCgR", "color__space___y_co_cg_8inl.html#gaeee43c2a06fe63d46a96cee4d1c63ce6", null ],
    [ "YCoCg2rgb", "color__space___y_co_cg_8inl.html#gab40e31e352d2d318d3f062df2882c500", null ],
    [ "YCoCgR2rgb", "color__space___y_co_cg_8inl.html#ga7b90b9b5758dbe96a82a2ef8237a17e9", null ]
];