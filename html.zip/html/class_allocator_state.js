var class_allocator_state =
[
    [ "index", "class_allocator_state.html#a477bd5dcef3e6282913e92369119ce4c", null ],
    [ "remains", "class_allocator_state.html#a33830ce309a85feb8c9f820ab8a1052c", null ]
];