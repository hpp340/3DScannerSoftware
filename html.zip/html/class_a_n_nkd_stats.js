var class_a_n_nkd_stats =
[
    [ "ANNkdStats", "class_a_n_nkd_stats.html#abe2d418f36b4c0df3c35537f5c6ea83b", null ],
    [ "merge", "class_a_n_nkd_stats.html#abec3668063ce9eebd2e134e665abe290", null ],
    [ "reset", "class_a_n_nkd_stats.html#a7ebff910ff7fa893e8528989b0091b11", null ],
    [ "avg_ar", "class_a_n_nkd_stats.html#a8563e16c4dcab2da8c873c9f609dfec1", null ],
    [ "bkt_size", "class_a_n_nkd_stats.html#afa6109669ead4a488861b85bbb5a1298", null ],
    [ "depth", "class_a_n_nkd_stats.html#acc4bc70f06a2b1819668cc8f7295f1f0", null ],
    [ "dim", "class_a_n_nkd_stats.html#a2077dca3152bf466206e579633552631", null ],
    [ "n_lf", "class_a_n_nkd_stats.html#a27d983ec07e7e961d61fd26db4a0b84c", null ],
    [ "n_pts", "class_a_n_nkd_stats.html#a4b4b906e4f960004fa059eb15be9fa42", null ],
    [ "n_shr", "class_a_n_nkd_stats.html#a1c502a8489754676991facb606a649e8", null ],
    [ "n_spl", "class_a_n_nkd_stats.html#aa8163564d280c1ae86079aafd7954cdc", null ],
    [ "n_tl", "class_a_n_nkd_stats.html#a66fecafc9fc96b70b454504accbeaff5", null ],
    [ "sum_ar", "class_a_n_nkd_stats.html#a943634a11b1d087a9165b12dd40c6b88", null ]
];