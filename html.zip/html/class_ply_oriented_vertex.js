var class_ply_oriented_vertex =
[
    [ "PlyOrientedVertex", "class_ply_oriented_vertex.html#adae7631c4f5cf37b74925b286683d9c7", null ],
    [ "PlyOrientedVertex", "class_ply_oriented_vertex.html#a7f469ceb92d29c84902ded1a7bdb8e87", null ],
    [ "operator*", "class_ply_oriented_vertex.html#a9a9fe28151a66cc485ec893348c3f2f5", null ],
    [ "operator*=", "class_ply_oriented_vertex.html#ae0b1affb2b51a8dc4a379794c5f7f9fc", null ],
    [ "operator+", "class_ply_oriented_vertex.html#a7ea1bbc0acfac4a5679ce2aaa21a6464", null ],
    [ "operator+=", "class_ply_oriented_vertex.html#ab130b53069180866465c2d17e1698cb9", null ],
    [ "operator-", "class_ply_oriented_vertex.html#aaf919e514c67abcb9416b421d631af14", null ],
    [ "operator-=", "class_ply_oriented_vertex.html#aa42dc08bf554a42c02a5485e0d2ae4c8", null ],
    [ "operator/", "class_ply_oriented_vertex.html#a08044e6cf254351bfa703b21b0033fa8", null ],
    [ "operator/=", "class_ply_oriented_vertex.html#aa1a81c67c5ccb30bee20d55da48a77c2", null ],
    [ "Properties", "class_ply_oriented_vertex.html#a5ff3158209337dc6fe57c69263473b19", null ],
    [ "Properties", "class_ply_oriented_vertex.html#acc4c0cd742db81912f89eb23c5d2697f", null ],
    [ "normal", "class_ply_oriented_vertex.html#a97b272d2847f163d67140406602c3a54", null ],
    [ "point", "class_ply_oriented_vertex.html#ac715e84b068021fd4866bcce4175d9af", null ]
];