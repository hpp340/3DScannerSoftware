var color__space_8hpp =
[
    [ "hsvColor", "color__space_8hpp.html#ga9d3d99c06af10403d317dec0cb655090", null ],
    [ "luminosity", "color__space_8hpp.html#ga3fb6710bbbf4f3e2303b06946e9cf00c", null ],
    [ "rgbColor", "color__space_8hpp.html#gafe29cc37c2675aee66c9f9ae3e5e7294", null ],
    [ "saturation", "color__space_8hpp.html#ga444bcc8582eaa894acf405762ba2a5ff", null ],
    [ "saturation", "color__space_8hpp.html#ga1a6fe89b5effcc718b5f49de5bb50fad", null ],
    [ "saturation", "color__space_8hpp.html#ga42cc34c45ab66e010c629106952c8bdd", null ]
];