var class_j_mesh_1_1_j_face =
[
    [ "JFace", "class_j_mesh_1_1_j_face.html#ac83b7fce81fc2f73b9214521211efce8", null ],
    [ "JFace", "class_j_mesh_1_1_j_face.html#a61475de92c91a18bce38ac382c888fb3", null ],
    [ "JFace", "class_j_mesh_1_1_j_face.html#a2c3bcb5e0a541571c60d327db1744046", null ],
    [ "JFace", "class_j_mesh_1_1_j_face.html#a79721a610fc3dab8af4b305c8efe072e", null ],
    [ "~JFace", "class_j_mesh_1_1_j_face.html#a0485540ec1a8ba9f038a045703add66b", null ],
    [ "getFaceNormal", "class_j_mesh_1_1_j_face.html#a1556ae1127d66e614e23455beebaae80", null ],
    [ "isNormalSet", "class_j_mesh_1_1_j_face.html#ac6b7859ed34db9cf507c7b22ce20a7d3", null ],
    [ "isTextureSet", "class_j_mesh_1_1_j_face.html#a5d224b9aa6a2f87f968812515495accf", null ],
    [ "setFaceId", "class_j_mesh_1_1_j_face.html#a2244a4826dfc3fd22b2e9c8a5d00b222", null ],
    [ "setFaceNormal", "class_j_mesh_1_1_j_face.html#a30ec0107df60dea416e17398dc7687c7", null ],
    [ "faceId", "class_j_mesh_1_1_j_face.html#a8212f82c781134a1f687bfab9dace68b", null ],
    [ "faceNormal", "class_j_mesh_1_1_j_face.html#ac2da2712443e8d851c2ab42390756ffa", null ],
    [ "normalSet", "class_j_mesh_1_1_j_face.html#a16490aa1476dbf1f90be6f27a5f82efa", null ],
    [ "texture1Id", "class_j_mesh_1_1_j_face.html#a2a6bb238bd3bdda2c5db893be3555519", null ],
    [ "texture2Id", "class_j_mesh_1_1_j_face.html#a8287b901fbb39170d24228d0fadaad2f", null ],
    [ "texture3Id", "class_j_mesh_1_1_j_face.html#ac0cc7ce8d04f729b5c2e38394f1fdc26", null ],
    [ "textureSet", "class_j_mesh_1_1_j_face.html#ad78630897e551a0142903f117bc6481a", null ],
    [ "vert1Id", "class_j_mesh_1_1_j_face.html#ad00d0c312b5cecb0c0e613ec38123cdc", null ],
    [ "vert2Id", "class_j_mesh_1_1_j_face.html#aeab96ee3413baec37cc84d93d5e68aac", null ],
    [ "vert3Id", "class_j_mesh_1_1_j_face.html#a29014b36cc40fe51b9b8f978e4effcb1", null ]
];