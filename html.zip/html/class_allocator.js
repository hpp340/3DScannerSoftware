var class_allocator =
[
    [ "Allocator", "class_allocator.html#a4ea8174fa46b7cab012bce28c1d7b15a", null ],
    [ "~Allocator", "class_allocator.html#abebd763de32757a2cc5319c31ede9f71", null ],
    [ "getState", "class_allocator.html#acf150c1dad1cfe3b9e09e4a231da8bd5", null ],
    [ "newElements", "class_allocator.html#ab8b94b02e0ae28df795e3a6448d5d56f", null ],
    [ "reset", "class_allocator.html#a8958e9d08950818a86f30acafdd3cc24", null ],
    [ "rollBack", "class_allocator.html#a50fe95414d5d1072e819ba030f05471a", null ],
    [ "rollBack", "class_allocator.html#a0766a945688bf8cf695478458e60fa14", null ],
    [ "set", "class_allocator.html#a07db1bc74ce034c67c9ff6fa8f17101c", null ],
    [ "blockSize", "class_allocator.html#a9a2406e23b34691708f33acbff52a303", null ],
    [ "index", "class_allocator.html#afc9a42da476699e0cb0fea6b42cab24f", null ],
    [ "memory", "class_allocator.html#a594bf2075ce98a7f9bc556ef156dfdcc", null ],
    [ "remains", "class_allocator.html#a01ad71db6e50d669220ba5434f46b445", null ]
];