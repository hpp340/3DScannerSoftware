var class_octree_1_1_refine_function =
[
    [ "Function", "class_octree_1_1_refine_function.html#a24e7891528a222b6673bbb0ee5555362", null ],
    [ "depth", "class_octree_1_1_refine_function.html#ab11ffba54c5eecdd50e689546a10af07", null ]
];