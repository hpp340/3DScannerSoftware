var class_oct_node_1_1_adjacency_count_function =
[
    [ "Function", "class_oct_node_1_1_adjacency_count_function.html#a2daf9d450780d0ce8f1ada1e019d3945", null ],
    [ "count", "class_oct_node_1_1_adjacency_count_function.html#a3d93f500a3fd15c8b4eaaa9942928e45", null ]
];